<?php
class UrlConstants
{
	static $api_gateway_url_pk = "https://api.daraz.pk/rest";
	static $api_gateway_url_bd = "https://api.daraz.bd/rest";
	static $api_gateway_url_lk = "https://api.daraz.lk/rest";
	static $api_gateway_url_np = "https://api.daraz.np/rest";
	static $api_gateway_url_mm = "https://api.daraz.mm/rest";
}
