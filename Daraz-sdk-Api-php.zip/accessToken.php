<?php
include "Daraz-sdk-php/php/LazopSdk.php";
try {

    $c = new LazopClient('https://api.daraz.com.bd/rest','Your App Key','Your Secret Key');
    $request = new LazopRequest('/seller/get','GET');

    $response = $c->execute($request, 'Your Access Token ');


    var_dump($response);

}catch(Exception $e) {
    //var_dump($e);
}
?>
