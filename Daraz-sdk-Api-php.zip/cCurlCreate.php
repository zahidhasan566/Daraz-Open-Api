<?php
include "Daraz-sdk-php/php/LazopSdk.php";
try {
    $c = new LazopClient('https://api.daraz.com.bd/rest','Your App Key','Your Secret Key');
    $request = new LazopRequest('/auth/token/create');
    $request->addApiParam('code','Your Access Code ');
    $response = $c->execute($request);
    var_dump($response);
}catch(Exception $e) {
    var_dump($e);
}
?>
